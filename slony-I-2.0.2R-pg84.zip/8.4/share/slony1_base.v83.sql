-- ----------------------------------------------------------------------
-- slony1_base.v83.sql
--
--    Version 8.3 specific parts of the basic replication schema.
--
--	Copyright (c) 2007, PostgreSQL Global Development Group
--	Author: Jan Wieck, Afilias USA INC.
--
-- $Id: slony1_base.v83.sql,v 1.1 2007-05-31 18:55:28 wieck Exp $
-- ----------------------------------------------------------------------


