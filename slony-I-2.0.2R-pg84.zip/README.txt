This is Slony Version 2.0.2
Only a binary is offered by the reason no margin of time is. 

1. Install
C:\Progrem Files\PostgreSQL\8.4 <=== this path is fixation. 

make date: 2009.07.07

Hiroshi Saito
